Here are a couple of (admittedly trivial) examples of using facilities provided by B7094 to debug a program running on the emulator.

## The Stops window

For the simple three-link chain job demo in FORTRAN II, the compiler storage map shows the addresses of integer variables I, J, and K (in the COMMON block shared among all three links) as having addresses:

####
    I: 77461(8)  (= 32561(10) )
    J: 77460(8)  (= 32560(10) )
    K: 77457(8)  (= 32559(10) )

"I" is at the tippy-top of COMMON, which grows downward (toward lower addresses).

Now it's a peculiarity of FORTRAN II running under IBSYS that -- whatever addresses the storage-map part of the compiler listing shows -- COMMON **actually** starts **below** 76400(8) (= 32000(10) ); i.e., starting at  76377(8) (= 31999(10) ), and growing downward from there.  So the addresses shown by the compiler are systematically offset -- they're too high -- by 370(8) (= 562(10) ).

I suspect that maybe the listing addresses would've been correct with the standalone FMS system, but that IBSYS just isn't bothering to correct the storage-map listing when running FORTRAN II as a "subsystem" (FORTRAN II was already a "legacy" feature of IBSYS).  Perhaps IBSYS is using more of the very highest core locations, above COMMON, for buffer storage.

You can see where FORTRAN II COMMON actually starts by doing some variable tracing using the Stops and Log/Trace windows (including when running the relocatable version of the following job: you don't have to re-run the compiler for this demonstration. But in either case, you might want to select the 'Dark' radiobutton on the Control Panel to save time.).  Start the emulator, and select 'Continue the demonstration (silent)', 'Load the KSYS61 IBSYS tape', 'Run demo jobs using the FORTRAN II Processor', 'Run the above jobs as pre-compiled relocatable binaries'.  **Before** clicking 'A FORTRAN II "chain" job with three links sharing data', click the 'Stops' and 'Trace' radiobuttons on the Control Panel to bring up the 'Process Stops and Tracing' and 'Log/Trace display' windows.  Set the Stops window to 'Trace' (radiobutton) 'On Store to location:' 76377 (the top of COMMON) (and check the 'Enabled' checkbox):

<p align="center">
<img src="Stops_screenshot1.jpg" width="65%">
</p>

On the Log/Trace window, **uncheck** the 'Clear on Reset' checkbox (this is important). The 'Auto Display' checkbox will be checked by default. Click the 'Core Write' checkbox under 'Trace Display filters' (the right-hand set of checkboxes):

<p align="center">
<img src="Log_Trace_screenshot1.jpg" width="65%">
</p>

Click the 'Dark' radiobutton on the Control Panel to save some time. **Now** click 'A FORTRAN II "chain" job with three links sharing data' on the Scripter dialog window (the demo menu). After the program runs, click 'Continue' on the Scripter dialog window to dismiss the Tape Viewer window. The Log/Trace window will now show:

<p align="center">
<img src="Log_Trace_screenshot2.jpg" width="65%">
</p>

Now decrement the 'On Store to location' address on the Stops window by 1 (you'll have to re-check the 'Enabled' checkbox after you change the address):

<p align="center">
<img src="Stops_screenshot2.jpg" width="65%">
</p>

Once again, click 'A FORTRAN II "chain" job with three links sharing data' on the Scripter dialog window (the demo menu). After the program runs, click 'Continue' on the Scripter dialog window to dismiss the Tape Viewer window. The Log/Trace window will now show:

<p align="center">
<img src="Log_Trace_screenshot3.jpg" width="65%">
</p>

Repeat the above process one more time with the 'On Store to location' address on the Stops window again decremented by 1 (don't forget to re-check the 'Enabled' checkbox after you change the address).  After clicking 'Continue' on the Scripter dialog window to dismiss the Tape Viewer window, the Log/Trace window will finally show:

<p align="center">
<img src="Log_Trace_screenshot4.jpg" width="65%">
</p>

Note that the final Log/Trace window shows values (in the "Decrement" part -- the upper 18-bit [6 octal digit] half of a 36-bit [12 octal digit] word, where integer data is stored) of:

####
    I: 14(8)  (=12(10) )
    J: 42(8)  (=34(10) )
    K: 70(8)  (=56(10) )

Those are the integer values that the first link of the 3-link chain demo is reading into COMMON (I, J, and K at locations 76377, 76376 and 76375 respectively) from the first card following the "*     DATA" control card.

If you now click 'Clear' on the Log/Trace window or 'Power Off' the emulator, you'll get a 'Warning' dialog with the question "Save current trace data?". If you click "Yes", a file ..\Output\B7094.TRC will be written (overwriting any file of the same name that's already in the ..\Output directory, so it's safest to re-name \*.TRC files right away if you need to keep them).

## A somewhat more complicated example

The included "STRESS III" demo program in FORTRAN II/FAP -- the "Structural Engineering System Solver" from MIT -- includes a dynamic memory allocator (coded in FAP -- the "FORTRAN Assembly Program") in each of its 6 chain links. The allocator may have been intended as a general-purpose tool at the time it was written at MIT, and not just specific to STRESS. In any case, it parcels out memory in the range between the storage used by the "monitor" (the operating system, in modern lingo), which would have been FMS (the FORTRAN Monitor System) at the time the program was actually being used, but which is IBSYS in our case) plus the storage occupied by user-program code, both in low core; and the bottom of COMMON in high core. So: bottom-of-high-core minus top-of-low-core is the available pool for the dynamic memory allocator.

The size of COMMON is expected to be counted up by the user, and is passed in as a parameter when the allocator is initialized. It's 301(10) in our case, from the transcribed MIT listing on bitsavers. There are other variables in the allocator that contain the address limits and size of the available storage pool. "N1" will contain the address of the first available word below common (the highest address, which is the beginning of the storage pool -- it grows downward, just like COMMON). "NT" will contain the last (lowest) address of the storage pool, where it bumps against storage used in low core. Under the FMS system (and in the original program listing), this address was obtained from the FMS monitor at location 99; for IBSYS we get it from the symbol "BOTTOM" (there's an "SST" pseudo-op in the assemblyl code to make the "System Symbol Table" available). "NMAX" is the available memory (N1-NT).

So just as a sanity check, it's interesting to see what's in these variables: N1, NT, and NMAX.

We can get their addresses from the storage map in the FORTRAN II output listing, but because of the "quirk" described above, they'll be systematically too high, by 370(8) (= 562(10) ), and will have to be corrected.  So:

####
    N1 is @ 77271(8)  (=32441(10) )   (compiler storage-map address)   TOP OF POOL
    N1 is @ 76207(8)  (=31879(10) )   (corrected address)              (first available)
    From Store to Address tracing + Log/Trace display:
    **** value in N1                             = 75723(8)  (= 31699(10) )

    NT is @ 77267(8)  (=32439(10) )   (compiler storage-map address)   BOTTOM OF POOL
    NT is @ 76205(8)  (=31877(10) )   (corrected address)              (last available)
    From Store to Address tracing + Log/Trace display:
    **** value in NT (from System Symbol BOTTOM) = 36124(8)  (= 15444(10) )

    NMAX  @ 77304(8)  (=32452(10) )   (compiler storage-map address)   size of pool
    NMAX  @ 76222(8)  (=31890(10) )   (corrected address)
    From Store to Address tracing + Log/Trace display:
    **** value in NMAX                           = 37577(8)  (= 16255(10) )

Do these values look plausible?  Well:

####
        32000(10) - N1<-31699(10) =         301(10) = size of COMMON
    N1<-31699(10) - NT<-15444(10) = NMAX<-16255(10) = size of allocator pool

So yes, the numbers look plausible.

## The Core View window

There's another way to peek into memory besides using the 'Log/Trace display' window. Here's an example.

Re-run the FORTRAN II three-link chain demo as described above: start the emulator, and select 'Continue the demonstration (silent)', 'Load the KSYS61 IBSYS tape', 'Run demo jobs using the FORTRAN II Processor', 'Run the above jobs as pre-compiled relocatable binaries'. Click the 'Dark' radiobutton on the Control Panel to save some time. 

**Before** clicking 'A FORTRAN II "chain" job with three links sharing data', click the 'Stops' radiobutton on the Control Panel to bring up the 'Process Stops and Tracing' window. Set the Stops window to 'Stop' (radiobutton) 'On Store to location:' 76375 (the third-from-the-top of COMMON) (and check the 'Enabled' checkbox):

<p align="center">
<img src="Stops_screenshot3.jpg" width="65%">
</p>

Now click the 'CoreView' radiobutton on the Control Panel to bring up the 'IBM 7302 Core Storage' window. The 'Address:' text-entry box will be highlighted; type the <backspace> key to clear it, and then type 76375 followed by the <return> key:

<p align="center">
<img src="CoreView_screenshot1.jpg" width="65%">
</p>

**Now** click 'A FORTRAN II "chain" job with three links sharing data' on the Scripter dialog window (the demo menu). A moment after "$EXECUTE   FORTRAN" appears on the lineprinter and the CPU will stop (message at the bottom of the Console window: "Stopped - Store to Address 76375 (000000000000)" and this Scripter dialog window will appear:

<p align="center">
<img src="UserStop_screenshot.jpg" width="50%">
</p>

Click 'Continue' to dismiss the dialog window. Click the blue 'Start' button on the Console window to re-start the CPU. Now you'll get to "BEGIN EXECUTION-00.000V13T48" on the lineprinter, and the CPU will stop again with the same message at the bottom of the Console window: "Stopped - Store to Address 76375 (000000000000)". One more time, click the blue 'Start' button on the Console window. Once again, the CPU will stop, but this time with the message: "Stopped - Store to Address 76375 (000070000000)". This was the store of "K" to common in the first chain link. You'll now see values (starting at the left of the first row) for "K", "J" and "I" in the Core View window (remember, top of COMMON is at 76377 and it grows downward).

<p align="center">
<img src="CoreView_screenshot2.jpg" width="65%">
</p>

## The Core Plot window

This is perhaps the least-effective tool available in B7094, because it slows execution down to a crawl. It's mostly there for entertainment. But it may be possible to make use of it with short programs. It's a graphical display of core usage, with memory locations represented by blocks of colored pixels. Pixels are black initially, a write to a location turns it blue, a read from a location turns it green, a (pending) instruction fetch flashes a pixel white (before the actual fetch turns it green). This is what the Core Plot looks like during the three-link chain demo, just after "BEGIN EXECUTION" appears on the lineprinter:

<p align="center">
<img src="CorePlot_screenshot.jpg" width="65%">
</p>
