Here are a couple of (admittedly trivial) examples of using facilities provided by B7094 to debug a program running on the emulator.

## The Stops window

For the simple three-link chain job demo in FORTRAN II, the compiler storage map shows the addresses of integer variables I, J, and K (in the COMMON block shared among all three links) as having addresses:

####
    I: 77461(8)  (= 32561(10) )
    J: 77460(8)  (= 32560(10) )
    K: 77457(8)  (= 32559(10) )

"I" is at the tippy-top of COMMON, which grows downward (toward lower addresses).

Now it's a peculiarity of FORTRAN II running under IBSYS that -- whatever addresses the storage-map part of the compiler listing shows -- COMMON **actually** starts **below** 76400(8) (= 32000(10) ); i.e., starting at  76377(8) (= 31999(10) ), and growing downward from there.  So the addresses shown by the compiler are systematically offset -- they're too high -- by 370(8) (= 562(10) ).

I suspect that maybe the listing addresses would've been correct with the standalone FMS system, but that IBSYS just isn't bothering to correct the storage-map listing when running FORTRAN II as a "subsystem" (FORTRAN II was already a "legacy" feature of IBSYS).  Perhaps IBSYS is using more of the very highest core locations, above COMMON, for buffer storage.

You can see where FORTRAN II COMMON actually starts by doing some variable tracing using the Stops and Log/Trace windows (including when running the relocatable version of the following job: you don't have to re-run the compiler for this demonstration. But in either case, you might want to select the 'Dark' radiobutton on the Control Panel to save time.).  Start the emulator, and select 'Continue the demonstration (silent)', 'Load the KSYS61 IBSYS tape', 'Run demo jobs using the FORTRAN II Processor', 'Run the above jobs as pre-compiled relocatable binaries'.  **Before** clicking 'A FORTRAN II "chain" job with three links sharing data', click the 'Stops' and 'Trace' radiobuttons on the Control Panel to bring up the 'Process Stops and Tracing' and 'Log/Trace display' windows.  Set the Stops window to 'Trace' (radiobutton) 'On Store to location:' 76377 (the top of COMMON) (and check the 'Enabled' checkbox):

<p align="center">
<img src="Stops_screenshot1.jpg" width="65%">
</p>

On the Log/Trace window, **uncheck** the 'Clear on Reset' checkbox (this is important). The 'Auto Display' checkbox will be checked by default. Click the 'Core Write' checkbox under 'Trace Display filters' (the right-hand set of checkboxes):

<p align="center">
<img src="Log_Trace_screenshot1.jpg" width="65%">
</p>

Click the 'Dark' radiobutton on the Control Panel to save some time. **Now** click 'A FORTRAN II "chain" job with three links sharing data' on the Scripter dialog window (the demo menu). After the program runs, click 'Continue' on the Scripter dialog window to dismiss the Tape Viewer window. The Log/Trace window will now show:

<p align="center">
<img src="Log_Trace_screenshot2.jpg" width="65%">
</p>

Now decrement the 'On Store to location' address on the Stops window by 1 (you'll have to re-check the 'Enabled' checkbox after you change the address):

<p align="center">
<img src="Stops_screenshot2.jpg" width="65%">
</p>

Once again, click 'A FORTRAN II "chain" job with three links sharing data' on the Scripter dialog window (the demo menu). After the program runs, click 'Continue' on the Scripter dialog window to dismiss the Tape Viewer window. The Log/Trace window will now show:

<p align="center">
<img src="Log_Trace_screenshot3.jpg" width="65%">
</p>

Repeat the above process one more time with the 'On Store to location' address on the Stops window again decremented by 1 (don't forget to re-check the 'Enabled' checkbox after you change the address).  After clicking 'Continue' on the Scripter dialog window to dismiss the Tape Viewer window, the Log/Trace window will finally show:

<p align="center">
<img src="Log_Trace_screenshot4.jpg" width="65%">
</p>

Note that the final Log/Trace window shows values (in the "Decrement" part -- the upper 18-bit [6 octal digit] half of a 36-bit [12 octal digit] word, where integer data is stored) of:

####
    I: 14(8)  (=12(10) )
    J: 42(8)  (=34(10) )
    K: 70(8)  (=56(10) )

Those are the integer values that the first link of the 3-link chain demo is reading into COMMON (I, J, and K at locations 76377, 76376 and 76375 respectively) from the first card following the "*     DATA" control card.

If you now click 'Clear' on the Log/Trace window or 'Power Off' the emulator, you'll get a 'Warning' dialog with the question "Save current trace data?". If you click "Yes", a file ..\Output\B7094.TRC will be written (overwriting any file of the same name that's already in the ..\Output directory, so it's safest to re-name \*.TRC files right away if you need to keep them).

## A somewhat more complicated example

The included "STRESS III" demo program in FORTRAN II/FAP -- the "Structural Engineering System Solver" from MIT -- includes a dynamic memory allocator (coded in FAP -- the "FORTRAN Assembly Program") in each of its 6 chain links. The allocator may have been intended as a general-purpose tool at the time it was written at MIT, and not just specific to STRESS. In any case, it parcels out memory in the range between the storage used by the "monitor" (the operating system, in modern lingo), which would have been FMS (the FORTRAN Monitor System) at the time the program was actually being used, but which is IBSYS in our case) plus the storage occupied by user-program code, both in low core; and the bottom of COMMON in high core. So: bottom-of-high-core minus top-of-low-core is the available pool for the dynamic memory allocator.

The size of COMMON is expected to be counted up by the user, and is passed in as a parameter when the allocator is initialized. It's 301(10) in our case, from the transcribed MIT listing on bitsavers. There are other variables in the allocator that contain the address limits and size of the available storage pool. "N1" will contain the address of the first available word below common (the highest address, which is the beginning of the storage pool -- it grows downward, just like COMMON).

"NT" will contain the last (lowest) address of the storage pool, where it bumps against storage used in low core. Under the FMS system (and in the original program listing), this address was obtained from the FMS monitor at location 99; for IBSYS we get it from the symbol "(PCBK)" There's an "SST" pseudo-op in the assembly code to make the "System Symbol Table" available:

####
    IBM 7090/7094 Programming Systems
    FORTRAN II Assembly Program (FAP)
    Form GC28-6235-5 (Apr. 1965)
    ( bitsavers.org/pdf/ibm/7090/C28-6235-5_FAP_Apr65.pdf )
    APPENDIX C: SYSTEM SYMBOL TABLE, FORTRAN MONITOR, P. 69

    Core allocation symbols
    . . .
    (PCBK)    COMMON break,,object program program break

The syntax above indicates that "(PCBK)" actually contains two values: "COMMON break" in the address field (low 15 bits [5 octal digits], and the "PROG BREAK" in the decrement field (high 18 bits [6 octal digits]). It's the latter we want. In the allocator FAP source code, this looks like:

####
    *      CLA     99                                                       ALOC0026
           CLA     (PCBK)
           ADD     ONE                                                      ALOC0027
           ARS     18                                                       ALOC0028
           STA     NT                                                       ALOC0029
    *      STA     99                                                       ALOC0030

(The original references to "99" are commented out.)


"NMAX" is the size of the memory pool available to the allocator (N1-NT).

So just as a sanity check, it's interesting to see what's in these variables: N1, NT, and NMAX.

We can get their addresses from the storage map in the FORTRAN II output listing, but because they're in COMMON, and because of the "quirk" described above, they'll be systematically too high, by 370(8) (= 562(10) ), and will have to be corrected. But the address of (PCBK) from the System Symbol Table is correct in the listing. So:

####
    N1 is @ 77271(8)  (=32441(10) )   (compiler storage-map address)   TOP OF POOL
    N1 is @ 76207(8)  (=31879(10) )   (corrected address)              (first available)

    NT is @ 77267(8)  (=32439(10) )   (compiler storage-map address)   BOTTOM OF POOL
    NT is @ 76205(8)  (=31877(10) )   (corrected address)              (last available)

    NMAX  @ 77304(8)  (=32452(10) )   (compiler storage-map address)   size of pool
    NMAX  @ 76222(8)  (=31890(10) )   (corrected address)

    (PCBK)@ 03733(8)  (=2011(10) )    (compiler storage-map address)   COMMON break,,PROG break

So let's try getting the contents of these variables using the Stops and Log/Trace windows. This time, we're running (from the demo menu) 'Continue the demonstration (silent)', 'Load the KSYS61 IBSYS tape', 'Run demo jobs using the FORTRAN II Processor', 'Run the above jobs as pre-compiled relocatable binaries'.  **Before** clicking 'Structural Engineering System Solver III', click the 'Stops' and 'Trace' radiobuttons on the Control Panel to bring up the 'Process Stops and Tracing' and 'Log/Trace display' windows.  Set the Stops window to 'Trace' (radiobutton) 'On Store to location:' 76207 (the corrected address of N1) (and check the 'Enabled' checkbox). On the Log/Trace window, **uncheck** the 'Clear on Reset' checkbox (this is important). The 'Auto Display' checkbox will be checked by default. Click the 'Core Write' checkbox under 'Trace Display filters' (the right-hand set of checkboxes). **Definitely** click the 'Dark' radiobutton on the Control Panel to save time with this job! **Now** click 'Structural Engineering System Solver III' on the Scripter dialog window (the demo menu). After the program runs, click 'Continue' on the Scripter dialog window to dismiss the Tape Viewer window. The Log/Trace window will now show:

<p align="center">
<img src="Log_Trace_screenshot5.jpg" width="65%">
</p>

Making sense of this trace display requires a bit of interpretation. It's clearly the 4th entry that's the one we're looking for; the others are irrelevant. So "N1" has (in its address field, while the 6 links are executing) 75723(8).

Now click 'Clear' on the Log/Trace screen (answer 'No' to the question about saving the current trace data), and on the Stops window change the 'On Store to location:' address to 76205 (the corrected address of NT) (and re-check the 'Enabled' checkbox). Re-run the program. Now, the Log/Trace window has:

<p align="center">
<img src="Log_Trace_screenshot6.jpg" width="65%">
</p>

So, with a bit of interpretation, "NT" has in its address field 43371(8).

Note that both "N1" and "NT" each get stored to (by the STRESS III program itself) exactly **once**, when the storage allocator is initialized at the beginning of the first chain link.

Let's check this against the contents of (PCBK) at address 03733(8).  Repeating the above process gives:

<p align="center">
<img src="Log_Trace_screenshot7.jpg" width="65%">
</p>

The value of "(PCBK)" actually changes each time one of our program's chain links is loaded into memory, but it's the value when the first link is loaded for the first time (when the storage allocator is initialized) that's relevant here.  It is 04337075723(8).  The decrement field plus one is our NT (43371(8) ), and 75723(8) is indeed the first available address below COMMON, the same as our N1.

As a last check, lets get the value of NMAX at 76222(8).  This one is almost impossible to pick out from the noise of the system writing to this location before and after the program runs, using the above method (there are 12,138 entries in the trace list for stores to address 76222).  So a workaround is: put a Stop, instead of a Trace, 'On Store to location:" 76207 (address of N1) in the Stops window. Uncheck the 'Core Write' checkbox under 'Trace Display filters' on the Log/Trace window. Run the program. Re-start the CPU each time it stops, until you see the message 'Stopped - Store to Address 76207 (000000075723)' at the bottom of the Console window. **Now** change the Stops window to Trace 'On Store to location:' 76222 and check the 'Core Write' checkbox under 'Trace Display filters' on the Log/Trace window. Start the CPU again. Now there are only 23 lines in the trace display, and the first line is the droid we're looking for:

<p align="center">
<img src="Log_Trace_screenshot8.jpg" width="65%">
</p>

"NMAX" is a FORTRAN integer variable, so the value is in the decrement field.

So, finally:

####
    From Store to Address tracing + Log/Trace display:
    **** value in N1                              = 75723(8)  (= 31699(10) )
    From Store to Address tracing + Log/Trace display:
    **** value in NT (from System Symbol (PCBK) ) = 43371(8)  (= 18169(10) )
    From Store to Address tracing + Log/Trace display:
    **** value in NMAX                            = 32332(8)  (= 13530(10) )

Do these values look plausible?  Well:

####
        32000(10) - N1<-31699(10) =         301(10) = size of COMMON
    N1<-31699(10) - NT<-18169(10) = NMAX<-13530(10) = size of allocator pool

So yes, the numbers look plausible.

Also, compare these numbers with the with the line in ..\Output\StressIII.out (the dump of SysOut.BCD from the Tape Viewer) following the subroutine list for the first chain link:

####
    PROG BREAK 43370  LOW COMMON 75723  AVAIL CORE 32333

The version of "9CHN" (the library routine invoked by the FORTRAN II "CALL CHAIN(R,T)" subroutine call) used by MIT along with the dynamic memory allocator, under the standalone FORTRAN Monitor System, checked the available core memory each time a chain link was loaded, and adjusted the allocator limits accordingly (and called the allocator's "REORG" if necessary to invoke the allocator's tape-based "virtual memory" capability). In our case, we are using an IBSYS-standard version of 9CHN, which doesn't integrate with the memory allocator. Fortunately, the first link of STRESS III has the most code and the biggest COMMON, so the available-memory limits established when the allocator is initialized by the first link remain "safe" for the other 5 links.

## The Core View window

There's another way to peek into memory besides using the 'Log/Trace display' window. Here's an example.

Re-run the FORTRAN II three-link chain demo as described above: start the emulator, and select 'Continue the demonstration (silent)', 'Load the KSYS61 IBSYS tape', 'Run demo jobs using the FORTRAN II Processor', 'Run the above jobs as pre-compiled relocatable binaries'. Click the 'Dark' radiobutton on the Control Panel to save some time. 

**Before** clicking 'A FORTRAN II "chain" job with three links sharing data', click the 'Stops' radiobutton on the Control Panel to bring up the 'Process Stops and Tracing' window. Set the Stops window to 'Stop' (radiobutton) 'On Store to location:' 76375 (the third-from-the-top of COMMON) (and check the 'Enabled' checkbox):

<p align="center">
<img src="Stops_screenshot3.jpg" width="65%">
</p>

Now click the 'CoreView' radiobutton on the Control Panel to bring up the 'IBM 7302 Core Storage' window. The 'Address:' text-entry box will be highlighted; type the \<backspace\> key to clear it, and then type 76375 followed by the \<return\> key:

<p align="center">
<img src="CoreView_screenshot1.jpg" width="65%">
</p>

**Now** click 'A FORTRAN II "chain" job with three links sharing data' on the Scripter dialog window (the demo menu). A moment after "$EXECUTE   FORTRAN" appears on the lineprinter the CPU will stop (with a message at the bottom of the Console window: "Stopped - Store to Address 76375 (000000000000)") and this Scripter dialog window will appear:

<p align="center">
<img src="UserStop_screenshot.jpg" width="50%">
</p>

Click 'Continue' to dismiss the dialog window. Click the blue 'Start' button on the Console window to re-start the CPU. Now you'll get to "BEGIN EXECUTION-00.000V13T48" on the lineprinter, and the CPU will stop again with the same message at the bottom of the Console window: "Stopped - Store to Address 76375 (000000000000)". One more time, click the blue 'Start' button on the Console window. Once again, the CPU will stop, but this time with the message: "Stopped - Store to Address 76375 (000070000000)". This was the store of "K" to COMMON in the first chain link. You'll now see values (starting at the left of the first row) for "K", "J" and "I" in the Core View window (remember, the top of COMMON is at 76377 and it grows downward).

<p align="center">
<img src="CoreView_screenshot2.jpg" width="65%">
</p>

## The Core Plot window

This is perhaps the least-effective tool available in B7094, because it slows execution down to a crawl. It's mostly there for entertainment. But it may be possible to make use of it with short programs. It's a graphical display of core usage, with memory locations represented by blocks of colored pixels. A pixel block is black initially, a write to a location turns it blue, a read from a location turns it green, a (pending) instruction fetch flashes a pixel-block white (before the actual fetch turns it green). This is what the Core Plot looks like during the three-link chain demo, just after "BEGIN EXECUTION" appears on the lineprinter:

<p align="center">
<img src="CorePlot_screenshot.jpg" width="65%">
</p>
