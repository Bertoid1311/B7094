Sources for the documents mentioned in the demos (which are far
too big to include here):

1. MAMOS.pdf
   ----------------------
   MAMOS: A MONITOR SYSTEM UNDER _IBSYS_ FOR THE IBM 7090/7094
   by Alfred E. Beam
   Prepared by UNIVERSITY OF MARYLAND College Park, Md.
   for NATIONAL AERONAUTICS AND SPACE ADMINISTRATION
   WASHINGTON D.C. MAY 1966
   (NASA CONTRACTOR REPORT   NASA CR-488)
   ----------------------
   https://ntrs.nasa.gov/api/citations/19660017936/downloads/19660017936.pdf

2. MAMOS_UMES_relationship.jpg
   ----------------------
   Screenshot of page 3.1-1 of the above document
   (MAMOS Monitor System Under IBSYS, Introduction)
   p. 29 in PDF
   ----------------------

3. UMES.pdf
   ----------------------
   UNIVERSITY OF MICHIGAN EXECUTIVE SYSTEM
   for the IBM 7090 Computer
   VOLUME I, VOLUME II, VOLUME III
   SEPTEMBER 1965
   UNIVERSITY OF MICHIGAN LIBRARY
   BUS. ADM. LIBRARY QA76.8 I23 M62 1965
   Vol I.   p.   5 in PDF
   Vol II.  p. 247 in PDF
   Vol III. p. 675 in PDF
   ----------------------
   https://babel.hathitrust.org/cgi/pt?id=mdp.35128002527891

4. The_MAD_manual_(Univ_of_Michigan_1966).pdf
   ----------------------
   The Michigan Algorithm Decoder (The MAD Manual)
   Bruce W. Arden
   Revised Edition, 1966
   University of Michigan
   College of Engineering Technical Reports
   Technical Report UMR0497
   ----------------------
   https://deepblue.lib.umich.edu/handle/2027.42/3292
   (and via Google Books)

5. Univ_of_Illinois_MAD_manual_62.pdf
   ----------------------
   A User's Reference Manual
   For The Michigan Algorithm Decoder (MAD)
   For The IBM 7090
   for the IBM 7090 Computer
   Library Routine L2-UOI-MAD1-2-RX
   R. Flenner, J. Flenner
   June 20, 1962
   DIGITAL COMPUTER LABORATORY
   GRADUATE COLLEGE
   UNIVERSITY OF ILLINOIS
   ----------------------
   https://bitsavers.org/pdf/univOfMichigan/mad/L2-UOI-MAD1-2-RX_MADum_62.pdf

6. Purdue_ALCOR_Users_Manual_Apr65.pdf
   ----------------------
   User's Manual
   for the ALCOR-University of Illinois
   ALGOL-60 Translater
   April 5, 1965
   COMPUTER SCIENCES CENTER
   PURDUE UNIVERSITY
   ----------------------
   https://bitsavers.org/pdf/univOfIllinoisUrbana/alcor/Purdue_ALCOR_Users_Manual_Apr65.pdf

7. ALCOR-ILLINOIS-7090_Users_Manual_Sep64.pdf
   ----------------------
   User's Manual
   for the ALCOR-ILLINOIS-7090
   ALGOL-60 Translator
   R. Bayer; E. Murphree, Jr.; D. Gries
   2nd ed., September 28, 1964
   DIGITAL COMPUTER LABORATORY
   GRADUATE COLLEGE
   UNIVERSITY OF ILLINOIS
   ----------------------
   https://ia801900.us.archive.org/21/items/usersmanualforal00univ/usersmanualforal00univ.pdf

8. Algol60_report_CACM_1960_June.pdf
   ----------------------
   Report on the Algorithmic Language ALGOL 60
   PETER NAUR (Editor); J. W. BACKUS et al.
   Communications of the ACM
   Vol. 3, No.5, May 1960
   ----------------------
   https://www.softwarepreservation.org/projects/ALGOL/report/Algol60_report_CACM_1960_June.pdf

9. SNOBOL3.pdf
   ----------------------
   The SNOBOL3 Programming Language
   Farber, D.J.; Griswold, R.E.; Polonsky, I.P.
   The Bell System Technical Journal
   July-August 1966
   ----------------------
   https://archive.org/details/bstj45-6-895

10. SNOBOL4.pdf
   ----------------------
   THE SNOBOL4 PROGRAMMING LANGUAGE
   Second Edition
   R.E. Griswold, J.F.Poage, I.P.Polonsky
   Bell Telephone Laboratories/Prentice Hall, 1971
   ----------------------
   http://berstis.com/greenbook.pdf

11. IPLV.pdf
   ----------------------
   INFORMATION PROCESSING LANGUAGE-V MANUAL
   Allen Newell; Fred M. Tonge; Edward A. Feigenbaum;
   Bert F. Green, Jr.; George H. Meally
   Second Edition (prepared by Hugh S. Kelly, Allen Newell)
   The RAND Corporation/Prentice Hall, 1964
   ----------------------
   https://bitsavers.org/pdf/rand/ipl/Information_Processing_Language-V_Second_Edition_1964.pdf

12. IPLV_Ref.pdf
   ----------------------
   IPL-V PROGRAMMERS' REFERENCE MANUAL
   Allen Newell, ed.
   RAND Corporation Research Memorandum RM-3739-RC
   June, 1963
   ----------------------
   https://www.rand.org/content/dam/rand/pubs/research_memoranda/2008/RM3739.pdf

13. IPLV_Ackermanns.pdf
   ----------------------
   TALL -- A List Processor for the Philco 2000 Computer
   J. Feldman
   Communications of the ACM
   Vol. 5, No. 9
   September, 1962
   ----------------------
   https://dl.acm.org/doi/pdf/10.1145/368834.368899

14. IPL-V_coding_sheet.jpg
   ----------------------
   IPL-V - Blank Coding Sheet
   The Edward A. Feigenbaum Papers
   Stanford Libraries
   Call Number: SC0340, Accession: 1986-052, Box: 46, Folder: 52
   ----------------------
   https://exhibits.stanford.edu/feigenbaum/catalog/my596dw6311

15. SIMULA.pdf
   ----------------------
   SIMULA--an ALGOL-Based Simulation Language
   Ole-Johan Dahl and Kristen Nygaard
   Norwegian Computing Center, Oslo, Norway
   Programming Languages column (D.E. Knuth, ed.)
   Communications of the ACM, Vol. 9 No. 9
   September, 1966
   ----------------------
   https://dl.acm.org/doi/10.1145/365813.365819

16. OMNITAB.pdf
   ----------------------
   OMNITAB
   A Computer Program For Statistical and Numerical Analysis
   Joseph Hilsenrath, Guy G. Ziegler, Carla G. Messina,
   Philip J. Walsh, and Robert J. Herbold
   United States Department of Commerce
   National Bureau of Standards Handbook 101
   Issued March 4, 1966
   Reissued January 1968, with corrections.
   Library of Congress Catalog Card Number: 65-61853
   ----------------------
   https://nvlpubs.nist.gov/nistpubs/Legacy/hb/nbshandbook101.pdf


And see also:

Algol 60 implementations and dialects
by Paul McJones
https://www.softwarepreservation.org/projects/ALGOL/algol60impl/

