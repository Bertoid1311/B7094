Sources for the documents mentioned in the demos (which are far
too big to include here):

1. MAMOS.pdf
   ----------------------
   MAMOS: A MONITOR SYSTEM UNDER _IBSYS_ FOR THE IBM 7090/7094
   by Alfred E. Beam
   Prepared by UNIVERSITY OF MARYLAND College Park, Md.
   for NATIONAL AERONAUTICS AND SPACE ADMINISTRATION
   WASHINGTON D.C. MAY 1966
   (NASA CONTRACTOR REPORT   NASA CR-488)
   ----------------------
   https://ntrs.nasa.gov/api/citations/19660017936/downloads/19660017936.pdf

2. MAMOS_UMES_relationship.jpg
   ----------------------
   Screenshot of page 3.1-1 of the above document
   (MAMOS Monitor System Under IBSYS, Introduction)
   p. 29 in PDF
   ----------------------

3. UMES.pdf
   ----------------------
   UNIVERSITY OF MICHIGAN EXECUTIVE SYSTEM
   for the IBM 7090 Computer
   VOLUME I, VOLUME II, VOLUME III
   SEPTEMBER 1965
   UNIVERSITY OF MICHIGAN LIBRARY
   BUS. ADM. LIBRARY QA76.8 I23 M62 1965
   Vol I.   p.   5 in PDF
   Vol II.  p. 247 in PDF
   Vol III. p. 675 in PDF
   ----------------------
   https://babel.hathitrust.org/cgi/pt?id=mdp.35128002527891

4. The_MAD_manual_(Univ_of_Michigan_1966).pdf
   ----------------------
   The Michigan Algorithm Decoder (The MAD Manual)
   Bruce W. Arden
   Revised Edition, 1966
   University of Michigan
   College of Engineering Technical Reports
   Technical Report UMR0497
   ----------------------
   https://deepblue.lib.umich.edu/handle/2027.42/3292
   (and via Google Books)

5. Univ_of_Illinois_MAD_manual_62.pdf
   ----------------------
   A User's Reference Manual
   For The Michigan Algorithm Decoder (MAD)
   For The IBM 7090
   for the IBM 7090 Computer
   Library Routine L2-UOI-MAD1-2-RX
   R. Flenner, J. Flenner
   June 20, 1962
   DIGITAL COMPUTER LABORATORY
   GRADUATE COLLEGE
   UNIVERSITY OF ILLINOIS
   ----------------------
   https://bitsavers.org/pdf/univOfMichigan/mad/L2-UOI-MAD1-2-RX_MADum_62.pdf

6. Purdue_ALCOR_Users_Manual_Apr65.pdf
   ----------------------
   User's Manual
   for the ALCOR-University of Illinois
   ALGOL-60 Translater
   April 5, 1965
   COMPUTER SCIENCES CENTER
   PURDUE UNIVERSITY
   ----------------------
   https://bitsavers.org/pdf/univOfIllinoisUrbana/alcor/Purdue_ALCOR_Users_Manual_Apr65.pdf

7. The_ALCOR_Illinois_7090_7094_Post_Mortem_Dump.pdf
   ----------------------
   The ALCOR Illinois 7090/7094
   Post Mortem Dump
   E. Bayer, D. Gries, M. Paul and H. R. Wiehle
   Communications of the ACM, Programming Techniques
   Vol. 10, No. 12
   December, 1967
   ----------------------
   https://www.cs.cornell.edu/gries/Papers/The_Alcor_Illinois_7090_7094_Post_Mortem_Dump.pdf

8. OMNITAB.pdf
   ----------------------
   OMNITAB
   A Computer Program For Statistical and Numerical Analysis
   Joseph Hilsenrath, Guy G. Ziegler, Carla G. Messina,
   Philip J. Walsh, and Robert J. Herbold
   United States Department of Commerce
   National Bureau of Standards Handbook 101
   Issued March 4, 1966
   Reissued January 1968, with corrections.
   Library of Congress Catalog Card Number: 65-61853
   ----------------------
   https://nvlpubs.nist.gov/nistpubs/Legacy/hb/nbshandbook101.pdf


And see also:

Algol 60 implementations and dialects
by Paul McJones
https://www.softwarepreservation.org/projects/ALGOL/algol60impl/

