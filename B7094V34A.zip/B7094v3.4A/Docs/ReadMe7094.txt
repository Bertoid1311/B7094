This is a much improved version of my IBM 7094 Emulator program.

Files in the B7094xxx.ZIP:-
  Readme7094.txt   - This file
  WhatsNew7094.txt - Change log
  Syntax7094.txt   - Scripting language syntax description
  B7094.exe    	   - The emulator program
  9M21.CBN         - 9M21 diagnostic program card file
  DIAG1.BIN        - 9M71B diagnostic program tape file
  ASYS1.BIN        - IBSYS Operating System tape file
  ASYS8.BIN        - IBSYS System Library tape file
  IBSYSA.TXT       - IBSYS Source with addresses
  B7094.ini        - Emulator confguration file
  B7Demo.EC7       - Script files
  IBSYSDemo.EC7    - ""
  Diag9M21.EC7     - ""
  Diag9B71.EC7     - ""
  TestJob1.JCL	   - A stupid deck of demo IBSYS JCL
  Hello.FOR        - A simple Fortran "Hello world" program

Installation:-
Unzip all files to a new folder.


Operation:-
Run B7094.EXE.
The configuration file B7094.INI specifies that the script file "B7Demo.EC7"
is to be run on startup. This script runs a few demonstrations.

These operations can also be run manually:-

To run the diags 9M21.CBN (card) and 9M71A.BIN (tape):-

SSW1 must be off for these.
Use the reader or tape "open" buttons to load the diagnostic program.
Click "Load Card" or "load Tape"
For 9M71B only:-
Wait for it to load, then click "Start".
When listing stops, hit start 3 more times (wait each time).

Both programs produce error output listings, and then loop or stop.

To run a program again:-
hit "Stop" if required
hit "Clear"
hit "Reload" or "Rewind" in the Reader or Tape windows if required
hit "Load Card" or "Load Tape"

Experiment at will:-
  Almost all controls display hints/tooltips.
  Examine the trace display to see what's happening inside.
  Experiment with IBSYS job control commands.
  Experiment with scripts. No documentation yet, but it's fairly self evident.
  Try other software from the site below.
  To really get "Das lights" a "blinken", uncheck the "Core", "Show" and
  "Upd" checkboxes.

Further resources:-
More software and documentation are available from Paul Pierce's web site:-
http://www.piercefuller.com/oldibm-shadow/709x.html
and related pages.

Large amounts of documentation are available from Al Kossow's web site:-
http://bitsavers.org/pdf/ibm
and related pages.


Acknowledgements:-
Many, many, many thanks to Paul and Al for preserving this stuff and
making it available. Without the software, this would be a very hollow
project. Without the documentation, it would be an impossible project.

Many thanks also to:-

Mike Hore for his enthusiasm and hard work in developing the implementation
of the floating point instructions.

James Fehlinger for his huge effort to get the Fortran compiler running.


Status:-
See "Whatsnew7094.txt"


Source code notes and implementation details:-
See "ReadMe7094Source.txt"


Appearance:-
The main console looks more like a 7044 than a 7094, since that was the original
inspiration for this project. Future versions may improve on this.


Feedback:-
Comments, suggestions, bug reports and any other help in furthering this project
are most welcome. Please send to intabits@optushome.com.au or in any relevant
(and current) public forum threads.

Rob Storey

