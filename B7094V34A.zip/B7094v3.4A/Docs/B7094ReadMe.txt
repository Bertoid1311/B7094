If you're a "casual" user, and running Windows, just:

Run either B7094.32.exe or B7094.64.exe in the "Bin" sub-folder of
the folder (B7094v3.4A, by default) that was created when you extracted
the B7094V34A.zip archive that you downloaded from GitHub
( https://github.com/Bertoid1311/B7094 ).

The canned suite of demo scripts will start immediately.  You have the
choice of continuing in "verbose" mode, which will display lots of
explanatory text as you proceed through the demos; or "silent" mode,
which will display mostly just the clickable option lists on
subsequent screens (which are still pretty self-explanatory, if you
want to skip the lectures).

The first screen after the initial screen gives you a choice between
two versions of IBSYS.  You can pick either of these and run demos,
but **some** of the demos (particularly those involving FORTRAN II)
are only available if you pick 'Load the KSYS61 IBSYS tape'.

After that, you pick one of the major "subsystems" of IBSYS: either
FORTRAN II (more-or-less a "legacy" subsystem), or IBJOB (which offered
more "modern" languages like FORTRAN IV and COBOL).  Start the demos
in "verbose" mode to get more detailed explanations of all this.

You might also want to take a look at the file 'B7094SuggestedManuals.txt'
in this Docs directory.

B7094 makes no changes to the Windows registry or any other part of the system other
than its install folder. Deleting the distribution archive and the install folder will
completely remove B7094 from your system.

There is a YouTube video here:
https://www.youtube.com/watch?v=4xaBS6pWrG0)
that shows the use and operation of B7094 (for the earlier v3.3B release,
but the basic operation is the same.

A newer video mmay be forthcoming on the same channel. Stay tuned!
