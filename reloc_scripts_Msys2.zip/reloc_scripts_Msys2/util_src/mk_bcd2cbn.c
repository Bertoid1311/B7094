#include <stdio.h>

int main ()
{
   fputc(011, stdout);
   fputc(011, stdout);
   fputc(0107, stdout);
   fputc(0107, stdout);
}
