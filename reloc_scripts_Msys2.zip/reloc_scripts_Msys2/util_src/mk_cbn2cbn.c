#include <stdio.h>

int main ()
{
   fputc(0100, stdout);
   fputc(0105, stdout);
   fputc(0100, stdout);
   fputc(1, stdout);
   fputc(0100, stdout);
   fputc(0105, stdout);
   fputc(0100, stdout);
   fputc(4, stdout);
}
