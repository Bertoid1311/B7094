
#include <stdlib.h>
#include <stdio.h>

#include "sysdef.h"
#include "cvtpar.h"
#include "prsf2.h"

extern char fin[300], fon[300];

static uint8        odd_parity_table[64] = {
    /* 0    1    2    3    4    5    6    7 */
    0100, 0000, 0000, 0100, 0000, 0100, 0100, 0000,
    0000, 0100, 0100, 0000, 0100, 0000, 0000, 0100,
    0000, 0100, 0100, 0000, 0100, 0000, 0000, 0100,
    0100, 0000, 0000, 0100, 0000, 0100, 0100, 0000,
    0000, 0100, 0100, 0000, 0100, 0000, 0000, 0100,
    0100, 0000, 0000, 0100, 0000, 0100, 0100, 0000,
    0100, 0000, 0000, 0100, 0000, 0100, 0100, 0000,
    0000, 0100, 0100, 0000, 0100, 0000, 0000, 0100
};

/* Column binary to BCD

   This is based on documentation in the IBM 1620 manual and may not be
   accurate for the 7094.  Each row (12,11,0,1..9) is interpreted as a bit
   pattern, and the appropriate bits are set.  (Double punches inclusive
   OR, eg, 1,8,9 is 9.)  On the 1620, double punch errors are detected;
   since the 7094 only reads column binary, double punches are ignored.

   Bit order, left to right, is 12, 11, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9.
   The for loop works right to left, so the table is reversed. */

static const char row_val[12] = {
    011, 010, 007, 006, 005, 004,
    003, 002, 001, 020, 040, 060
    };

static char colbin_to_bcd (uint32 cb)
{
uint32 i;
char bcd;

for (i = 0, bcd = 0; i < 12; i++) {                     /* 'sum' rows */
    if (cb & (1 << i))
        bcd |= row_val[i];
    }
return bcd;
}

/* BCD to ASCII conversion */

const char bcd_to_ascii_h[64] = {
    ' ', '1', '2', '3', '4', '5', '6', '7',
    '8', '9', '^', '=', '\'', ':', '>', '{',
    '0', '/', 'S', 'T', 'U', 'V', 'W', 'X',
    'Y', 'Z', '|', ',', '(', '~', '\\', '"',
    '-', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
    'Q', 'R', '!', '$', '*', ']', ';', '_',
    '+', 'A', 'B', 'C', 'D', 'E', 'F', 'G',
    'H', 'I', '?', '.', ')', '[', '<', '}'
    };

#define MAXREC 101

int main (int argc, char **argv)
{
   char *optarg;
   int optind;
   FILE *fi, *fo;
   t_bool fixrec = FALSE;
   t_bool expect_pad_after_eof = FALSE;
   t_bool quiet_eof = FALSE;
   int inch0, inch1;
   char ouch, outline[MAXREC];
   int chrcnt, spcnt, reccnt, reclen;
   t_bool found_rec_mark;
   uint32 colbin;

   if (argc == 1)
   {
     goto usage;
   }

   for (optind = 1, optarg = argv[optind];
       (optind < argc) && ((*optarg == '-') || (*optarg == '/'));
       optind++, optarg = argv[optind])
   {
      ++optarg;
      while (*optarg)
      {
         switch(*optarg++)
	 {
         case 'f':
            fixrec = TRUE;
            break;

         case 'F':
            fixrec = TRUE;
            expect_pad_after_eof = TRUE;
            break;

         case 'q':
            quiet_eof = TRUE;
            break;

         default:
            goto usage;
         }
      }
   }

   reclen = 80;
   parsefiles(argc - (optind-1), &argv[optind-1], "cbn", "txt", &reclen);

   if ((reclen+1) > MAXREC)
   {
      fprintf(stderr, "Specified output record length too large; max %d\n", MAXREC-1);
      exit(1);
   }

   if ((fi = fopen(fin, "rb")) == NULL)
   {
      perror(fin);
      exit(1);
   }
   if ((fo = fopen(fon, "w")) == NULL)
   {
      perror(fon);
      exit(1);
   }

   chrcnt = 0;
   reccnt = 0;
   spcnt = 0;
   found_rec_mark = FALSE;
   while ( (inch0 = fgetc(fi)) != EOF )
   {
      /* Check for EOF card                              */
      /* (7,8 punch value in 1st [not 2nd, in this case] */
      /* byte of 1st col, plus record mark)              */

      if (inch0==0217)
      {
        int i;

eof_again:
        if ( fixrec && expect_pad_after_eof && (chrcnt>0 && chrcnt<reclen) )
        {
          fprintf(stderr, "Incomplete input record at %d\n", reccnt+1);
          exit(1);
        }

        /* This starts a new record            */
        /* Flush the last one, if there is one */

        if ( (reccnt>0) && (outline[0]!='~') )
        {
          outline[chrcnt-spcnt] = 0;
          fprintf(fo, "%s\n", outline);
          reccnt++;
        }

        /* Print the EOF marker */

        outline[1] = 0;
        if (quiet_eof)
        {
          outline[0] = 0;
        }
        else
        {
          outline[0] = '~';
        }
        fprintf(fo, "%s\n", outline);
        outline[0] = '~';  /* It's also a flag */
        chrcnt = 0;
        spcnt = 0;
        found_rec_mark = FALSE;
        reccnt++;

        if (fixrec && expect_pad_after_eof)
        {
          /* Skip the rest of the input record */

          i = 2;
          while ( (inch0 = fgetc(fi)) != EOF )
          {
            if (inch0 == EOF)
            {
              fprintf(stderr, "Incomplete input record at %d\n", reccnt+1);
              exit(1);
            }
            else if (i++ >= 2*reclen)
            {
              break;
            }
          }
        }
        else
        {
          /* Look for the next record mark, */
          /* or another EOF mark,           */
          /* or the end of the file         */

          while ( (inch0 = fgetc(fi)) != EOF )
          {
            if (inch0 == EOF)
            {
              goto finished;
            }
            else if (inch0 == 0217)
            {
              goto eof_again;
            }
            else if (inch0 & 0x80)
            {
              goto nextbyte;
            }
          }
        }

        continue;
      }

nextbyte:
      if ( (inch1 = fgetc(fi)) == EOF )
      {
        fprintf(stderr, "Incomplete input record at %d\n", reccnt+1);
        exit(1);
      }

      if ( ((reccnt==0) && (chrcnt==0)) || outline[0]=='~' )  /* First character in input file, or        */
      {                                                       /* we just handled an EOF marker            */
        if ( ! (inch0 & 0x80) )                               /* Make sure there's an initial record mark */
        {
          fprintf(stderr, "Damaged input record at %d\n", reccnt+1);
          exit(1);
        }
        else
        {
          /* Clear the initial record mark  */

          inch0 &= 0x7F;

          /* (But don't flag the initial record mark) */
        }
      }
      else if (inch0 & 0x80)   /* Look out for subsequent record mark */
      {                        /* indicating first char of new record */
        if (fixrec)
        {
          if (chrcnt < reclen)
          {
            fprintf(stderr, "Incomplete input record at %d\n", reccnt+1);
            exit(1);
          }
          else if (chrcnt > reclen)
          {
            fprintf(stderr, "Input record too long at %d\n", reccnt+1);
            exit(1);
          }
          else
          {
            /* chrcnt (index of this char in output) == reclen       */
            /* indicates this will be first char in next record      */
            /* (index will be reset to 0 before char is saved)       */
          }
        }

        /* Clear the record mark */

        inch0 &= 0x7F;
        found_rec_mark = TRUE;
      }

      if (inch1 & 0x80)    /* I don't think this byte is supposed */
      {                    /* to have a record mark               */
        fprintf(stderr, "Damaged input record at %d\n", reccnt+1);
        exit(1);
      }

      /* Check the parity                                         */

      if (odd_parity_table[ (int)(inch0 & 077) ] !=
          (inch0 & 0100) )
      {
        fprintf(stderr, "Parity error in input record at %d\n", reccnt+1);
        exit(1);
      }
      else
      {
        inch0 &= 077;    /* Clear the parity bit (bit 6) */
      }

      if (odd_parity_table[ (int)(inch1 & 077) ] !=
          (inch1 & 0100) )
      {
        fprintf(stderr, "Parity error in input record at %d\n", reccnt+1);
        exit(1);
      }
      else
      {
        inch1 &= 077;    /* Clear the parity bit (bit 6) */
      }

      colbin = ((uint32)inch0) << 6 | (uint32)inch1;
 
      ouch = bcd_to_ascii_h[colbin_to_bcd(colbin)];

      if ( fixrec && (chrcnt > reclen) )
      {
        /* Shouldn't ever get here -- must be missing a record mark */

        fprintf(stderr, "Input record too long at %d\n", reccnt+1);
        exit(1);
      }
      else if (found_rec_mark)
      {
        /* Flush out the current output record before starting a new one */

        outline[chrcnt-spcnt] = 0;
        chrcnt = 0;
        spcnt = 0;
        found_rec_mark = FALSE;
        fprintf(fo, "%s\n", outline);
        reccnt++;                       /* Count the record */
      }

      outline[chrcnt++] = ouch;

      if (ouch == ' ')     /* Count trailing spaces, so we can get rid of them */
      {
        spcnt++;
      }
      else
      {
        spcnt = 0;
      }
   }

   if ( fixrec && (chrcnt > reclen) )
   {
     /* Shouldn't ever get here -- must be missing a record mark */

     fprintf(stderr, "Input record too long at %d\n", reccnt+1);
     exit(1);
   }
   else if (chrcnt > 0)    /* Last line still needs to be flushed     */
   {                       /* (unless file ended in an EOF card)      */
                           /* Easiest way to check this is chrcnt > 0 */
     outline[chrcnt-spcnt] = 0;
     fprintf(fo, "%s\n", outline);
     reccnt++;
   }

finished:
   fprintf(stdout, "%d records output\n", reccnt);

   exit(0);

usage:
   fprintf(stderr, "Usage: cbn2txt [-f] <infile> [<outfile>] [<output record len>, default 80]\n");
   fprintf(stderr, "  -f   Expect and verify fixed-length (default 160-byte) input records\n");
   fprintf(stderr, "  -q   Don't output '~' to indicate an EOF card; just use a blank line\n");
   exit(1);
}
